#include<iostream>

using namespace std;


class X
{
    int a;
    int b;
    public:
        X(int i, int j)
        {
            a = i;
            b = j;
            cout<<"One Arg Consturctor"<<endl;
        }
        // X(X &o)
        // {
        //     this->a = o.a;
        // }
        void display()
        {
            cout<<a<<", "<<b<<endl;
        }
};


int main()
{
    X obj(99,101);
    obj.display();

    X o2[3] = {X(1,1),X(2,4),X(3,9)};

    for(int i=0; i<3; i++)
    {
        o2[i].display();
    }
    return 0;
}