#include <iostream>
#include <string>

class person {
protected:
    std::string name;

public:
    
    person() = default;
    person(const std::string& );

    virtual void display_info();
    //std::string get_name();
    
};

person::person(const std::string& input_str) : name {input_str}{
    std::cout << "Person Name Inserted!" << std::endl;
}


void person::display_info() {
    std::cout << "Name: " << name << std::endl;
}

// std::string person::get_name() {
//     return name;
// }

// Employee Class

class employee : public person {
    std::string employee_id;

public:
    employee() = default;
    employee(const std::string& , const std::string&);

    void display_info();
};

employee::employee(const std::string& input_str1, const std::string& input_str2) 
: employee_id {input_str1}, person(input_str2) 

{
    std::cout << "Employee ID Inserted!" << std::endl;
}

void employee::display_info() {
    std::cout << "Name: " <<  name << std::endl;
    std::cout << "Employee ID: " << employee_id << std::endl;

}

// Stack Class

class emp_stack {
    int size;
    person** employee_stack;
    int top;
public:
    emp_stack() = default;

    emp_stack(const int& );

    void push(person *);
    void pop();

    person** get_stack();
};

emp_stack::emp_stack(const int& inp_size) {
    size = inp_size;
    employee_stack = new person*[size];
    top = -1;
}

void emp_stack::push(person * person_obj) {
    if (top == size - 1) {
        std::cout << "Overflow!! \n";
        return;
    }
    ++top;
    employee_stack[top] = person_obj;
}

void emp_stack::pop() {
    if (top == -1) {
        std::cout << "Underflow!! \n";
        return;
    }
    employee_stack[top] = nullptr;
}

person** emp_stack::get_stack() {
    return employee_stack;
}

int main() {
    
    emp_stack *emps = new emp_stack(3);

    employee em1("emp12", "Bijoy Das");

    employee em2("emp11", "Hrishik Das");

    person pm("Netaji");

    emps->push(&em1);
    emps->push(&em2);
    emps->push(&pm);

    person** per = emps->get_stack();


    per[2]->display_info();

    

    employee em3("emp13", "Bijoy Das");

    emps->push(&em3);
    emps->pop();


    return 0;
}
