#include <iostream>
#include <string.h>

class string_ops {
    char *str = nullptr;
    
public:
    string_ops() = default;

    string_ops(const char *);

    string_ops(string_ops& );

    ~string_ops();

    void display();

    void change(const char* );

};

string_ops::~string_ops() {
    delete(str);

    str = nullptr;
}


string_ops::string_ops(const char *input_str) {
    int len = strlen(input_str);
    str = new char[len + 1];

    for(int iter = 0; iter < len; iter++) {
        str[iter] = input_str[iter];
    } 

    str[len] = '\0';
}

string_ops::string_ops(string_ops& content) {
    change(content.str);
}

void string_ops::display() {
    std::cout << str << std::endl;
}

void string_ops::change(const char *input_str) {
    int len = strlen(input_str);

    delete(str);

    str = nullptr;

    str = new char[len + 1];

    for(int iter = 0; iter < len; iter++) {
        str[iter] = input_str[iter];
    } 

    str[len] = '\0';
}

int main() {

    string_ops str1("Hello World!!");

    string_ops str2 = str1;

    str1.display();
    str2.display();
    str2.change("Hello Sasken!!");
    str2.display();
    str1.display();

    return 0;

}