#include<iostream>
#include<memory>

using namespace std;


class Rectangle
{
    int width;
    int length;
    

    public:

    Rectangle(int l=0, int w=0)
    {
        this->length = l;
        this->width = w;
        
    }

    int area()
    {
        return (length*width);
    }
};

int main()
{
    unique_ptr<Rectangle> P1(new Rectangle(10,20));

    cout<<"\n P1 area : "<<(*P1).area();

    unique_ptr<Rectangle> P2;

    // P2 = P1;
    P2 = move(P1);

    cout<<"\n P2 area : "<<(*P2).area();
    cout<<"\n P1 area : "<<P1->area();

    return 0;
}