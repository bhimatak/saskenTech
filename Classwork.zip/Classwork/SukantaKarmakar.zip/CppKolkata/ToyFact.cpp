#include <iostream>
#include <string>
using namespace std;

class Toy {
    string name;
    float price;

public:
    virtual void prepareParts() = 0;
    virtual void combineParts() = 0;
    virtual void assembleParts() = 0;
    virtual void applyLabel() = 0;
    virtual void showProduct() = 0;

protected:
    Toy() {
        this->name = "No Name";
        this->price = 0.0;
    }
    Toy(string s, float p) {
        this->name = s;
        this->price = p;
    }

    string getName() {
        return this->name;
    }
    float getPrice() {
        return this->price;
    }
    void setName(string newName) {
        this->name = newName;
    }
    void setPrice(float newPrice) {
        this->price = newPrice;
    }
};

class Car : public Toy {
public:
    Car() {}

    Car(string name, float price) : Toy(name, price) {}

    void prepareParts() {
        cout << "\nPreparing Car Parts" << endl;
    }
    void combineParts() {
        cout << "Combining Car Parts" << endl;
    }
    void assembleParts() {
        cout << "Assembling Car Parts" << endl;
    }
    void applyLabel() {
        string newName;
        float newPrice;

        cout << "Applying Labels on Car" << endl;
        cout << "Enter new name for Car: ";
        cin >> newName;
        setName(newName);

        cout << "Enter new price for Car: ";
        cin >> newPrice;
        setPrice(newPrice);
    }
    void showProduct() {
        cout << "\nDetails of Car:" << endl;
        cout << "Name: " << getName() << endl;
        cout << "Price: " << getPrice() << endl;
    }
};

// Define Bike and Plane classes similarly...

class ToyFactory {
public:
    static Toy* createToy(int type);
};

Toy* ToyFactory::createToy(int type) {
    Toy* toy = nullptr;
    switch (type % 3) {
        case 0:
            toy = new Car("Car", 1000.0);
            break;
        // Add cases for Bike and Plane
        // case 1:
        //     toy = new Bike("Bike", 500.0);
        //     break;
        // case 2:
        //     toy = new Plane("Plane", 2000.0);
        //     break;
        default:
            break;
    }

    if (toy) {
        toy->prepareParts();
        toy->combineParts();
        toy->assembleParts();
        toy->applyLabel();
    }
    return toy;
}

int main(int argc, char* argv[]) {
    int type;
    if (argc > 1) {
        type = stoi(argv[1]);
    } else {
        type = 2;
    }

    Toy* t = ToyFactory::createToy(type);

    if (t) {
        t->showProduct();
        delete t; // Don't forget to delete the object to prevent memory leaks
    } else {
        cout << "Invalid toy type." << endl;
    }

    return 0;
}
