#include <iostream>

class MyClass {
private:
    int data;

public:
    MyClass(int d) : data(d) {}

    // Declare a friend function
    friend void displayData(const MyClass& obj);
};

// Define the friend function, which can access the private member
void displayData(const MyClass& obj) {
    std::cout << "Data: " << obj.data << std::endl;
}

int main() {
    MyClass obj(42);
    
    // Call the friend function from the main function
    displayData(obj);

    return 0;
}
