// #include <iostream>

// template <typename T>
// class SearchArray {
// public:
//     SearchArray(const T* arr, size_t size) : array(arr), arraySize(size) {}

//     bool search(const T& key) const {
//         for (size_t i = 0; i < arraySize; ++i) {
//             if (array[i] == key) {
//                 return true;
//             }
//         }
//         return false;
//     }

//     void displaySearchResult(const T& key) const {
//         if (search(key)) {
//             std::cout << "Found: " << key << std::endl;
//         } else {
//             std::cout << "Not Found: " << key << std::endl;
//         }
//     }

// private:
//     const T* array;
//     size_t arraySize;
// };

// int main() {
//     // Example array of integers
//     int intArray[] = {1, 2, 3, 4, 5};
//     SearchArray<int> intSearch(intArray, sizeof(intArray) / sizeof(intArray[0]));

//     int intKey;
//     std::cout << "Enter an integer to search: ";
//     std::cin >> intKey;
//     intSearch.displaySearchResult(intKey);

//     // Example array of strings
//     std::string strArray[] = {"apple", "banana", "cherry", "date"};
//     SearchArray<std::string> strSearch(strArray, sizeof(strArray) / sizeof(strArray[0]));

//     std::string strKey;
//     std::cout << "Enter a string to search: ";
//     std::cin.ignore();
//     std::getline(std::cin, strKey);
//     strSearch.displaySearchResult(strKey);

//     return 0;
// }

#include<iostream>
using namespace std;
class B
{

};
class D: public B{

};
int main()
{
    B* b=new D;
    D* d=dynamic_cast<D*>(b);
    if(d!=NULL)
    cout<<"works";
    else
    cout<<"cannot cast B* to D";
    getchar();
    return 0;
}