#include <iostream>


template <class T>
class node {
    T data;
    
public:
    node() = default;
    node(const T&); 
    
    void display();    
};

template <class T>
node<T>::node(const T& inp) :
    data {inp}
{
    
}

template <class T>
void node<T>::display() {
    std::cout << data;
}

int main() {
    
    void **node_ar = new void*[5];

    node<int> *n0 = new node<int>(0);
    node<std::string> *n1 = new node<std::string>("My Name"); 

    node_ar[0] = n0;
    
    node_ar[1] = n1;

    return 0;
}