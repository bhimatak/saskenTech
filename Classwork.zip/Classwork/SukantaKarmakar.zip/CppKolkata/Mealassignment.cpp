#include <iostream>
#include <string>

class Meal {
    std::string entry;
    int calorie;

public:
    Meal(const std::string& name = "Default Rice Meal", int calories = 1200) :
        entry(name),
        calorie(calories) {}

    friend std::istream& operator>>(std::istream& in, Meal& meal);
    friend std::ostream& operator<<(std::ostream& out, const Meal& meal);

    Meal operator+(const Meal& other) const;
};

std::istream& operator>>(std::istream& in, Meal& meal) {
    std::cout << "Enter Name of the Meal: ";
    getline(in >> std::ws, meal.entry);
    std::cout << "Enter the amount of calories: ";
    in >> meal.calorie;
    return in;
}

std::ostream& operator<<(std::ostream& out, const Meal& meal) {
    if (meal.entry.find(", ") != std::string::npos) {
        out << "Meal Summary: " << meal.entry << std::endl;
        out << "Total Daily Calories: " << meal.calorie << std::endl;
    } else {
        out << "Meal Name: " << meal.entry << std::endl;
        out << "Calories: " << meal.calorie << std::endl;
    }
    return out;
}

Meal Meal::operator+(const Meal& other) const {
    Meal result;
    result.entry = this->entry + ", " + other.entry;
    result.calorie = this->calorie + other.calorie;
    return result;
}

int main() {
    Meal ml("Pizza", 100);
    Meal ml1("Fried Rice", 120);
    Meal ml2("Chicken", 400);

    std::cout << ml1 << std::endl;

    Meal combined = ml + ml1 + ml2;

    std::cout << combined << std::endl;

    Meal userMeal;
    std::cin >> userMeal;

    std::cout << userMeal << std::endl;

    return 0;
}
