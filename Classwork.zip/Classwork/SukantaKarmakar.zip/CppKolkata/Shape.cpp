#include <iostream>
#include <cmath> // Include cmath for pi

using namespace std;

class Shape {
public:
    virtual double getArea() = 0;
};

class Square : public Shape {
    int side;

public:
    Square(int side = 0) {
        this->side = side;
    }

    ~Square() {}

    void setDim(int s) {
        this->side = s;
    }

    double getArea() {
        double area = side * side;
        return area;
    }
};

class Circle : public Shape {
    double radius;

public:
    Circle(double r = 0.0) {
        this->radius = r;
    }

    ~Circle() {}

    void setRadius(double r) {
        this->radius = r;
    }

    double getArea() {
        double area;
        area = M_PI * radius * radius; // Use M_PI for pi
        return area;
    }
};

int main() {
    Shape *ptr = NULL;

    ptr = new Square(5);
    cout << "Area of Square : " << ptr->getArea() << endl;

    delete ptr; // Delete the object when done with it

    ptr = new Circle(3.5);
    cout << "Area of Circle : " << ptr->getArea() << endl;

    delete ptr; // Delete the object when done with it

    return 0;
}
