#include <iostream>

class Complex {
private:
    double real;
    double imaginary;

public:
    Complex(double r, double i) : real(r), imaginary(i) {}

    // Overloading the + operator to add two Complex numbers
    Complex operator+(const Complex& other) const {
        double newReal = real + other.real;
        double newImaginary = imaginary + other.imaginary;
        return Complex(newReal, newImaginary);
    }

    // Function to display a Complex number
    void display() const {
        std::cout << real << " + " << imaginary << "i";
    }
};

int main() {
    Complex num1(3.0, 2.0);
    Complex num2(1.5, 4.5);

    Complex sum = num1 + num2; // Using the overloaded + operator

    std::cout << "Sum of ";
    num1.display();
    std::cout << " and ";
    num2.display();
    std::cout << " is ";
    sum.display();
    std::cout << std::endl;

    return 0;
}
