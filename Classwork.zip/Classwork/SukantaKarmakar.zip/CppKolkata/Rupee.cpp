#include<iostream>

using namespace std;

class Doller;

class Rupee
{
    double value;

public:
    Rupee()
    {
        this->value = 0.0;
    }

    Rupee(double val)
    {
        this->value = val;
    }

    double getValue()
    {
        return this->value;
    }

    // Modify the operator= to convert Rupees to Dollars
    void operator= (Doller &d);

    void print()
    {
        cout << "Rupees: " << this->value << endl;
    }
};

class Doller
{
    double value;

public:
    Doller()
    {
        this->value = 0.0;
    }

    Doller(double val)
    {
        this->value = val;
    }

    double getValue()
    {
        return this->value;
    }

    // Modify the operator= to convert Dollars to Rupees
    void operator= (Rupee &r);

    void print()
    {
        cout << "Dollars: " << this->value << endl;
    }
};

void Rupee::operator= (Doller &d)
{
    // Convert Dollars to Rupees
    this->value = d.getValue() * 82.0;
}

void Doller::operator= (Rupee &r)
{
    // Convert Rupees to Dollars
    this->value = r.getValue() / 82.0;
}

int main()
{
    Doller d(10);
    Rupee r(120);

    r = d; // Converts Dollars to Rupees

    d.print();
    r.print();

    return 0;
}
