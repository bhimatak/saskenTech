#include <iostream>
#include <cstring>

using namespace std;

template<class T>
class CustomArray
{
    T *arr;
    int size;

public:
    CustomArray(int len) : size(len)
    {
        arr = new T[size];
    }

    ~CustomArray()
    {
        delete[] arr;
    }

    void print()
    {
        for (int i = 0; i < size; i++)
        {
            cout << arr[i] << " ";
        }
        cout << "\n";
    }

    int search(const T& item)
    {
        for (int i = 0; i < size; i++)
        {
            if (arr[i] == item)
            {
                return i;
            }
        }
        return -1;
    }

    void setArray(const T* ptr, int len)
    {
        for (int i = 0; i < size && i < len; i++)
        {
            arr[i] = ptr[i];
        }
    }
};

int main()
{
    CustomArray<int> intArr(10);

    int intArray[] = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};

    intArr.setArray(intArray, 10);

    cout << "Integer Array: ";
    intArr.print();

    int flag = intArr.search(30);

    if (flag < 0)
    {
        cout << "Item not found" << endl;
    }
    else
    {
        cout << "Item found at position " << flag << endl;
    }

    CustomArray<string> strArr(6);

    string strArray[] = {"Apple", "Orange", "Banana", "Litchi", "Guava", "Pineapple"};

    strArr.setArray(strArray, 6);

    cout << "String Array: ";
    strArr.print();

    flag = strArr.search("Orange");

    if (flag < 0)
    {
        cout << "Item not found" << endl;
    }
    else
    {
        cout << "Item found at position " << flag << endl;
    }

    return 0;
}
